package com.tensorwine.application;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * Created by Virginia RdelC on 14/12/2017.
 */

public class Find extends AppCompatActivity {
    /** Items entered by the user is stored in this ArrayList variable */
    ArrayList<String> list = new ArrayList<String>();

    /** Declaring an ArrayAdapter to set items to ListView */
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.find);

        ListView listView = findViewById(R.id.listWine);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        for(int i = 0; i<Data.vinos.size();i++){
            list.add(Data.vinos.get(i).name);
        }
        adapter.notifyDataSetChanged();
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long id) {
               Data.getInstance().vino_seleccionado = (int)id;
               openVino(view);
            }

        });
    }

    public void openVino(View view){
        Intent intent = new Intent(this, DatosVino.class);
        startActivity(intent);
    }

}
