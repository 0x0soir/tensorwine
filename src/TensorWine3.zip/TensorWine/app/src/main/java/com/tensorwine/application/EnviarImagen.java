package com.tensorwine.application;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;


/**
 * Created by Virginia RdelC on 28/12/2017.
 */

public class EnviarImagen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.enviar_imagen);

        ImageView imgView = (ImageView) findViewById(R.id.imgView);
        // Set the Image in ImageView after decoding the String
        if(Data.getInstance().ruta_imagen!=null){
            imgView.setImageBitmap(BitmapFactory.decodeFile(Data.getInstance().ruta_imagen));
        }else{
            imgView.setImageBitmap(Data.getInstance().bitmap_imagen);
        }

    }


}