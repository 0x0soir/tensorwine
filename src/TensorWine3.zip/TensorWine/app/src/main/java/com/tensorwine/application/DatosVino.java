package com.tensorwine.application;

import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;

/**
 * Created by Virginia RdelC on 14/12/2017.
 */

public class DatosVino extends AppCompatActivity {
    private SimpleAdapter sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.datos_vino);

        int idVino = Data.getInstance().vino_seleccionado;
        Vino vino = Data.getInstance().vinos.get(idVino);

        TextView nombre = (TextView) findViewById(R.id.nombre);
        nombre.setText(vino.name);
        TextView owner = (TextView) findViewById(R.id.owner);
        owner.setText(vino.owner);

        RatingBar ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        LayerDrawable stars = (LayerDrawable) ratingBar.getProgressDrawable();
        ratingBar.setNumStars(5);
        ratingBar.setRating(vino.stars);

        sa = new SimpleAdapter(this, vino.generateData(),
                android.R.layout.simple_list_item_2,
                new String[] { "line1","line2" },
                new int[] {android.R.id.text1,android.R.id.text2});

        ((ListView)findViewById(R.id.list)).setAdapter(sa);

    }
}